from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from blog import models
from .models import Post
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required




def signup(request):
    if request.method == 'POST':
        name = request.POST.get('uname')
        email= request.POST.get('uemail')
        password = request.POST.get('upassword')
        newUser = User.objects.create_user(username=name, email=email, password=password)
        newUser.save()
        return redirect('/login')
    return render(request, 'blog/signup.html')




def login_view(request):
    if request.method == 'POST':
        name = request.POST.get('uname')
        password = request.POST.get('upassword')
        userr = authenticate(request, username=name, password=password)
        if userr is not None:
            login(request, userr)
            return redirect('/home')
        else:
            return redirect('/login')

    return render(request, 'blog/login.html')




def home(request):
    context = {
        'posts': Post.objects.filter(is_public=True)
    }
    return render(request, 'blog/home.html', context)



import os
from django.core.exceptions import ValidationError
from django.conf import settings
from PyPDF2 import PdfReader
import pandas as pd

def extract_pdf_text(file):
    reader = PdfReader(file)
    text = ""
    for page in reader.pages:
        text += page.extract_text() + "\n"
    return text.strip()

def extract_excel_text(file):
    df = pd.read_excel(file)
    return df.to_string()

def validate_file_extension(filename):
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ['.pdf', '.xls', '.xlsx']:
        raise ValidationError('Unsupported file extension.')

@login_required
def newPost(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        upload_file = request.FILES.get('upload')
        content = request.POST.get('content', '')
        is_public = request.POST.get('is_public') == 'true'

        if upload_file:
            try:
                validate_file_extension(upload_file.name)
            except ValidationError as e:
                return render(request, 'blog/newpost.html', {'error': str(e)})

            ext = os.path.splitext(upload_file.name)[1].lower()
            if ext == '.pdf':
                content = extract_pdf_text(upload_file)
            elif ext in ['.xls', '.xlsx']:
                content = extract_excel_text(upload_file)

            npost = models.Post(title=title, content=content, upload=upload_file, author=request.user, content_extracted=True, is_public=is_public)
        else:
            npost = models.Post(title=title, content=content, author=request.user, content_extracted=False, is_public=is_public)

        npost.save()
        return redirect('/home')
    
    return render(request, 'blog/newpost.html')




def myPost(request):
    context = {
        'posts': Post.objects.filter(author=request.user)
    }
    return render(request, 'blog/mypost.html', context)



def signout(request):
    logout(request)
    return redirect('/login')

