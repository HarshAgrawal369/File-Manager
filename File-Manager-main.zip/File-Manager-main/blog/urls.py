from django.urls import path
from django.shortcuts import redirect
from . import views

urlpatterns = [
    path('', views.signup, name='signup-page'),
    path('login/', views.login_view, name='login-page'),
    path('loginn/', lambda request: redirect('login-page', permanent=True)),
    path('home/', views.home, name='home-page'),
    path('newpost/', views.newPost, name='new-post'),
    path('mypost/', views.myPost, name='my-post'),
    path('signout/', views.signout, name='signout-btn'),
    
]
