from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Post(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    upload = models.FileField(upload_to='uploads/', null=True, blank=True)
    date_posted = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content_extracted = models.BooleanField(default=False)
    is_public = models.BooleanField(default=True)  # New field for public/private

    def __str__(self):
        return self.title
